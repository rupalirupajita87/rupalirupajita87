<!DOCTYPE html>
<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <div class="row mt-5">
           
            <form name="contact_form"  id="contact_form" action="" method="post">
            <h5 class="text-center bg-info">Contact Us</h5>
                <div class="mb-3">
                    <label for="full_name" class="col-sm-2 col-form-label">Full Name</label>
                    <div class="col-sm-10">
                    <input type="text"  class="form-control" id="full_name" name="full_name" autocomplit="off" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="email" class="col-sm-2 col-form-label">Email Address</label>
                    <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="subject" class="col-sm-2 col-form-label">Subject</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="subject" name="subject" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="message" class="col-sm-2 col-form-label">Message</label>
                    <div class="col-sm-10">
                    <textarea  class="form-control" id="message" name="message" required></textarea>
                    </div>
                </div>
                <div class="mb-3">
                <button type="submit" class="btn btn-primary">Send</button>
                </div>
               
                </div>
            </form>
            <div id='response_msg'></div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            $('#contact_form').on('submit',function(e){
                alert('hi');
                e.preventDefault();
                if($('#full_name').val()==''){
                    $('#full_name').css('border','1 px solid red');
                } else if($('#email').val()==''){
                    $('#email').css('email','1 px solid red');
                }
                else if($('#subject').val()==''){
                    $('#subject').css('subject','1 px solid red');
                }
                else if($('#message').val()==''){
                    $('#message').css('message','1 px solid red');
                }
                
                else{
                    var formData = $(this).serialize();
                    $.ajax({
                        type:'POST',
                        url: 'get_response.php',
                        data :formData,
                        success: function (data){
                            $('#response_msg').text(data);
                            //$('#response_msg').slideDown().fadeOut(30000);
                            $('#contact_form')[0].reset();
                        }
                    })
                }

            });
        });
    </script>
</body>
</html>