<?php
require_once('config.php');
if(isset($_POST)){
    if($_POST['full_name'] ==''){
        echo 'Please enter the Full name';
    }
    else if($_POST['email'] ==''){
        echo 'Please enter the email address';
    }
    else if($_POST['message'] ==''){
        echo 'Please enter the message';
    }
    else if($_POST['subject'] ==''){
        echo 'Please enter the subject';
    }
    else{
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $sql = "INSERT INTO contact_us( full_name , email , message , subject , ip_address) VALUES('".$full_name."' , '".$email."' , '".$message."' , '".$subject."' , '".$ip_address."')";
        //echo $sql;
        if(!$result = $conn->query($sql)){
            die('There was an error running the query['.$conn->error.']');
        }else{
            echo 'Thank you ! We will contact you soon';
        }
    }
}
?>
